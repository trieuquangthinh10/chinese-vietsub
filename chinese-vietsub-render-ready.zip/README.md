# Chinese → Vietnamese Vietsub Web (iPhone)

Bản này đã sửa lỗi chọn video trên iPhone và sửa lỗi backend trả file kết quả.

Cài trên SERVER:
1. Python 3.10+
2. FFmpeg
3. `pip install -r requirements.txt`
4. Đặt biến môi trường `OPENAI_API_KEY`
5. `cd backend`
6. `python server.py`

Mở trên iPhone:
`http://IP-SERVER:8000`

Nếu deploy online, dùng HTTPS. API key chỉ đặt ở server, không đặt trong frontend.

Lưu ý: đây là source để chạy trên server, không phải website đã được host sẵn.
