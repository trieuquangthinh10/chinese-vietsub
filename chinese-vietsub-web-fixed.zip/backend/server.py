import os, uuid, threading, subprocess
from pathlib import Path
from flask import Flask, request, jsonify, send_file, send_from_directory
from werkzeug.utils import secure_filename
from translator import process

BASE = Path(__file__).resolve().parent.parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
FRONTEND = BASE / "frontend"
UPLOADS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)

app = Flask(__name__)
jobs = {}

@app.get("/")
def home():
    return send_from_directory(FRONTEND, "index.html")

@app.get("/static/<path:name>")
def static_files(name):
    return send_from_directory(FRONTEND, name)

@app.post("/api/upload")
def upload():
    f = request.files.get("video")
    if not f or not f.filename:
        return jsonify(error="Chưa nhận được video"), 400
    jid = str(uuid.uuid4())
    safe = secure_filename(f.filename) or "video.mp4"
    path = UPLOADS / f"{jid}_{safe}"
    f.save(path)
    jobs[jid] = {"input": str(path), "progress": 5, "status": "uploaded", "status_text": "Đã upload video."}
    return jsonify(job_id=jid)

@app.post("/api/translate/<jid>")
def translate(jid):
    if jid not in jobs:
        return jsonify(error="Không tìm thấy job"), 404
    if jobs[jid]["status"] == "processing":
        return jsonify(ok=True)
    threading.Thread(target=run, args=(jid,), daemon=True).start()
    return jsonify(ok=True)

def run(jid):
    try:
        jobs[jid].update(status="processing", progress=15, status_text="Đang xử lý…")
        out = OUTPUTS / f"{jid}_VIETSUB.mp4"
        def cb(p, text):
            jobs[jid].update(progress=int(p), status_text=text)
        process(jobs[jid]["input"], str(out), cb)
        jobs[jid].update(output=str(out), progress=100, status="done", status_text="Hoàn tất!")
    except Exception as e:
        jobs[jid].update(status="error", error=str(e), status_text="Lỗi khi xử lý.")

@app.get("/api/status/<jid>")
def status(jid):
    return jsonify(jobs.get(jid, {"status":"unknown"}))

@app.get("/api/result/<jid>")
def result(jid):
    job = jobs.get(jid)
    if not job or "output" not in job:
        return jsonify(error="Video chưa sẵn sàng"), 404
    return send_file(job["output"], as_attachment=True, download_name="video_VIETSUB.mp4")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=False)
